#ifndef NO_SUCH_ELEMENT_EXCEPTION_H
#define NO_SUCH_ELEMENT_EXCEPTION_H

struct NoSuchElementException {};

#endif
